import React from 'react'
import stepCheck from "../../Assets/Images/icon/stepCheck.png";
import stepDot from "../../Assets/Images/icon/stepDot.png";

const RegistrationPanel = () => {
    return (
        <>
            <div className="tabPanel">
                <div className="tabHeading">
                    <ul className="tablist">
                        <li className="selected">
                            <div className="arrowLine">
                                <div className="checkCircle">
                                    <img src={stepCheck} alt='stepCheck' />
                                </div>
                            </div>
                            <div className="arrowHeading">
                                <h6>Personal Info</h6>
                                <p>Tell us who you are</p>
                            </div>
                        </li>
                        <li className="">
                            <div className="arrowLine">
                                <div className="checkCircle">
                                    <img src={stepDot} alt='stepCheck' />
                                </div>
                            </div>
                            <div className="arrowHeading">
                                <h6>Personal Info</h6>
                                <p>Tell us who you are</p>
                            </div>
                        </li>
                        <li className="">
                            <div className="arrowLine">
                                <div className="checkCircle">
                                    <img src={stepCheck} alt='stepCheck' />
                                </div>
                            </div>
                            <div className="arrowHeading">
                                <h6>Personal Info</h6>
                                <p>Tell us who you are</p>
                            </div>
                        </li>
                    </ul>
                </div>
                <div className="tabContent">

                </div>
            </div>
        </>
    )
}

export default RegistrationPanel